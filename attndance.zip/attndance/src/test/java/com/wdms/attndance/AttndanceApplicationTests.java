package com.wdms.attndance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttndanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
